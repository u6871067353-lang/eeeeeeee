# ThreeHearts
Paper 1.21.4 plugin - Three blue absorption hearts, PvP-only life loss, ban at 0.

Build instructions:
- Recommended: Use GitHub Actions (workflow included) to auto-build releases.
- Or build locally with Java 17 and Maven:
  mvn clean package
  (resulting jar in target/ThreeHearts-1.0.jar)

Resourcepack:
The plugin will set the server resource-pack to the configured URL (config.yml).
Default in config.yml points to your provided GitHub raw URL.
